PAINEL SM — Projeto Android versão 2.0

O QUE ESTA VERSÃO FAZ
- App Android com nome PAINEL SM.
- Perfis de sensibilidade: Equilibrado, Precisão e Rápido.
- Controles de sensibilidade de 0 a 200 para Geral, Ponto vermelho, Mira 2x,
  Mira 4x e Olhadinha.
- Dicas de treino, aquecimento e organização de HUD.
- Interface escura com detalhes vermelhos.

LIMITES IMPORTANTES
Este é um aplicativo auxiliar de configuração e treino. Não possui ESP real,
aimbot, leitura de inimigos, automação de tiros, injeção ou integração interna
com Free Fire. Não anuncie essas funções como existentes. O app não é afiliado
à Garena. As sensibilidades são sugestões editáveis e não mudam o jogo sozinhas.

COMO GERAR O APK
1. Instale o Android Studio em um computador.
2. Abra esta pasta como projeto ("Open").
3. Aguarde o Gradle sincronizar e instale o Android SDK 35 se solicitado.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de teste aparece em app/build/outputs/apk/debug/app-debug.apk.
6. Para vender, gere uma versão assinada em Build > Generate Signed Bundle / APK.
   Proteja sua chave de assinatura e faça testes em aparelhos reais antes de distribuir.

ANTES DE COMERCIALIZAR
- Teste instalação, abertura e controles em diferentes celulares.
- Defina preço, suporte e política de atualização.
- Use identidade visual própria e não use marcas/logos oficiais da Garena sem autorização.
- Não prometa funções que o aplicativo não oferece.
