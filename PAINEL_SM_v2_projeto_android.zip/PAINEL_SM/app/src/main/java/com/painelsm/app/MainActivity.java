package com.painelsm.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(13,13,18);
    private final int CARD = Color.rgb(29,29,37);
    private final int RED = Color.rgb(255,62,75);
    private TextView profileInfo;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void space(LinearLayout p, int h) {
        View v = new View(this); p.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }
    private void section(LinearLayout p, String title) {
        TextView t = label(title, 16, Color.WHITE, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(22); lp.bottomMargin = dp(8); p.addView(t, lp);
    }
    private void card(LinearLayout p, View child) {
        child.setPadding(dp(14), dp(12), dp(14), dp(12));
        child.setBackground(shape(CARD, 15));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(9); p.addView(child, lp);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout page = vertical();
        page.setPadding(dp(20), dp(26), dp(20), dp(28));
        scroll.addView(page);

        TextView title = label("PAINEL SM", 29, RED, true);
        title.setGravity(Gravity.CENTER); page.addView(title);
        TextView sub = label("CENTRAL DE CONFIGURAÇÕES • FREE FIRE", 10, Color.LTGRAY, true);
        sub.setGravity(Gravity.CENTER); page.addView(sub);
        space(page, 18);

        TextView note = label("APP AUXILIAR DE TREINO\\nNão altera o Free Fire, não injeta código e não oferece ESP ou aimbot funcional.", 12, Color.WHITE, false);
        card(page, note);

        section(page, "PERFIL DE SENSIBILIDADE");
        profileInfo = label("Perfil selecionado: Personalizado", 12, Color.LTGRAY, false);
        page.addView(profileInfo);
        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Equilibrado", "Precisão", "Rápido"};
        int[][] values = {{90,85,80,75,65},{96,92,88,82,70},{100,95,90,85,80}};
        for (int i=0; i<names.length; i++) {
            final int index = i;
            Button b = new Button(this); b.setText(names[i]); b.setTextSize(10);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(48), 1);
            bp.setMargins(dp(2), dp(8), dp(2), 0); presets.addView(b, bp);
            b.setOnClickListener(v -> {
                profileInfo.setText("Perfil selecionado: " + names[index]);
                applyPreset(values[index]);
            });
        }
        page.addView(presets);

        section(page, "AJUSTES DE SENSIBILIDADE");
        addSlider(page, "Geral", 90);
        addSlider(page, "Ponto vermelho", 85);
        addSlider(page, "Mira 2x", 80);
        addSlider(page, "Mira 4x", 75);
        addSlider(page, "Olhadinha", 65);

        section(page, "FERRAMENTAS DE TREINO");
        addInfoCard(page, "Treino de precisão", "Pratique puxadas curtas e controle o movimento no campo de treinamento.");
        addInfoCard(page, "Rotina de aquecimento", "Faça 5 minutos de mira parada, 5 minutos de rastreamento e 5 minutos de movimentação.");
        addInfoCard(page, "HUD", "Ajuste o tamanho e a posição dos botões dentro das configurações oficiais do jogo.");

        section(page, "SOBRE O PAINEL");
        TextView about = label("PAINEL SM • versão 2.0\\nAs sugestões são referências iniciais. Os resultados variam conforme aparelho, tela e preferência. Este app não é afiliado à Garena.", 11, Color.LTGRAY, false);
        card(page, about);

        setContentView(scroll);
    }

    private void applyPreset(int[] vals) {
        // Preset labels are updated through each SeekBar's tag.
        LinearLayout root = (LinearLayout)((ScrollView)findViewById(android.R.id.content).getChildAt(0)).getChildAt(0);
        int found = 0;
        for (int i=0; i<root.getChildCount(); i++) {
            View v = root.getChildAt(i);
            if (v instanceof SeekBar) {
                SeekBar sb = (SeekBar)v;
                if (found < vals.length) sb.setProgress(vals[found++]);
            }
        }
    }

    private void addSlider(LinearLayout page, String name, int initial) {
        LinearLayout box = vertical();
        TextView value = label(name + "  •  " + initial, 13, Color.WHITE, true);
        box.addView(value);
        SeekBar bar = new SeekBar(this); bar.setMax(200); bar.setProgress(initial);
        box.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                value.setText(name + "  •  " + progress);
                if (fromUser) profileInfo.setText("Perfil selecionado: Personalizado");
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        page.addView(box);
    }

    private void addInfoCard(LinearLayout page, String title, String body) {
        LinearLayout box = vertical();
        box.addView(label(title, 14, Color.WHITE, true));
        TextView desc = label(body, 11, Color.LTGRAY, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(5); box.addView(desc, lp);
        card(page, box);
    }
}
